/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author zachressler
 */
public class QuestionTest {
    
    public QuestionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of setDoesNotUnderstand method, of class Question.
     */
    @Test
    public void testSetDoesNotUnderstand() {
        System.out.println("setDoesNotUnderstand");
        Student student = null;
        Question instance = null;
        instance.setDoesNotUnderstand(student);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setUnderstand method, of class Question.
     */
    @Test
    public void testSetUnderstand() {
        System.out.println("setUnderstand");
        Student student = null;
        Question instance = null;
        instance.setUnderstand(student);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getStudentsWhoDoNotUnderstand method, of class Question.
     */
    @Test
    public void testGetStudentsWhoDoNotUnderstand() {
        System.out.println("getStudentsWhoDoNotUnderstand");
        Question instance = null;
        ArrayList<Student> expResult = null;
        ArrayList<Student> result = instance.getStudentsWhoDoNotUnderstand();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getStudentsWhoUnderstand method, of class Question.
     */
    @Test
    public void testGetStudentsWhoUnderstand() {
        System.out.println("getStudentsWhoUnderstand");
        Question instance = null;
        ArrayList<Student> expResult = null;
        ArrayList<Student> result = instance.getStudentsWhoUnderstand();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of resolveQuestion method, of class Question.
     */
    @Test
    public void testResolveQuestion() {
        System.out.println("resolveQuestion");
        Question instance = null;
        instance.resolveQuestion();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
