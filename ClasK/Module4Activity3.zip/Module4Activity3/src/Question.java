//@author Zach Ressler

import java.util.ArrayList;
public class Question {
    public boolean resolved;
    public String questionText;
    private ArrayList<String> answerList;
    private ArrayList<Student> studentsWhoDoNotUnderstand;
    private ArrayList<Student> studentsWhoUnderstand;
    
    public Question(String text) {
        questionText = text;
        resolved = false;
        answerList = new ArrayList<String>();
        studentsWhoDoNotUnderstand = new ArrayList<Student>();
        studentsWhoUnderstand = new ArrayList<Student>();
    }
    
    public void setDoesNotUnderstand(Student student) {
        if (studentsWhoUnderstand.contains(student)) {
            studentsWhoUnderstand.remove(student);
        }
        if (!studentsWhoDoNotUnderstand.contains(student)) {
            studentsWhoDoNotUnderstand.add(student);
        }
    }
    
    public void setUnderstand(Student student) {
        if (studentsWhoDoNotUnderstand.contains(student)) {
            studentsWhoDoNotUnderstand.remove(student);
        }
        if (!studentsWhoUnderstand.contains(student)) {
            studentsWhoUnderstand.add(student);
        }
    }
    
    public ArrayList<Student> getStudentsWhoDoNotUnderstand() {
        return studentsWhoDoNotUnderstand;
    }
    
    public ArrayList<Student> getStudentsWhoUnderstand() {
        return studentsWhoUnderstand;
    }
    
    public void resolveQuestion() {
        if (studentsWhoDoNotUnderstand.isEmpty()) {
            resolved = false;
        }
        else {
            resolved = true;
        }
    }
}
