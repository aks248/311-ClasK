
import java.util.ArrayList;
public class Driver {
    public static void main(String[] args) {
        Student zach = new Student("Zach Ressler", "IST 311");
        Student sharon = new Student("Sharon Gao", "CS 1550");
        
        Question q1 = new Question("What is the square root of 49?");
        Question q2 = new Question("Who will win the SuperBowl?");
        
        q1.setDoesNotUnderstand(sharon);
        q1.setUnderstand(zach);
        q1.setUnderstand(sharon);
        
        q2.setUnderstand(sharon);
        
    }
}
