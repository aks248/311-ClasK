//@author Zach Ressler

import java.util.ArrayList;
public class Student {
    public String name;
    private String course;
    
    public Student(String studentName, String courseName) {
        name = studentName;
        course = courseName;
    }
}